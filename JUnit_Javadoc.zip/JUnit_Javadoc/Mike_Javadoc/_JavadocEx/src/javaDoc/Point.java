package javaDoc;
/**
 * 
 * Point represents a point in a Cartesian Coordinate System
 * Points are immutable. They cannot be changed once they have been created.
 * @author wilmicj
 * @version 1.0
 *
 */

public class Point {
	private final int x;
	private final int y;
	
	/**
	 * Constructs and initializes a Point on position (x,y)
	 * @param x 
	 * x coordinate
	 * @param y 
	 * y coordinate
	 * 
	 */

	public Point(int x, int y){
		this.x = x;
		this.y = y;
	}
	
	/**
	 * Calculates the distance between this point and another
	 * point that was passed as an argument.
	 * 
	 * 
	 * @param other point to calculate the distance from.
	 * @return Testing the return method.
	 */	
	public double distance(Point other){
		return Math.hypot(x - other.x, y - other.y);
	}

	/**
	 *
	 * @return x coordinate
	 */
	public int getX(){
		return x;
	}

	/**
	 *
	 * @return return y coordinate
	 */
	public int getY(){
		return y;
	}
	
	@Override
	/**
	 * @return coordinates of each point (x,y).
	 */
	public String toString(){
		return "(" + x + "," + y + ")";
	}

}
