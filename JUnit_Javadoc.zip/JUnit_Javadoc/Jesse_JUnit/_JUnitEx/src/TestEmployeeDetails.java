/**
 * Created by Jesse Valley on 4/11/2017.
 */
import org.junit.Test;
import static org.junit.Assert.assertEquals;

/**
 * This class is where we set up the tests that we want to run with JUnit.
 * @author unascribed
 * @version 1.0
 */
public class TestEmployeeDetails {
    EmpBusinessLogic empBusinessLogic = new EmpBusinessLogic();
    EmployeeDetails employee = new EmployeeDetails();

    @Test
    /**
     * This method tests the appraisal calculation of the EmpBusinessLogic class.
     * <p>Here, we hard-coded values to make sure the actual result is what expect.</p>
     */
    public void testCalculateAppraisal() {
        employee.setName("Rajeev");
        employee.setAge(25);
        employee.setMonthlySalary(8000);

        double appraisal = empBusinessLogic.calculateAppraisal(employee);
        assertEquals(500, appraisal, 0.0);
    }

    @Test
    /**
     * This method tests the yearly salary calculation of the EmpBusinessLogic class.
     * <p>Here, we hard-coded values to make sure the actual result is what expect.</p>
     */
    public void testCalculateYearlySalary() {
        employee.setName("Rajeev");
        employee.setAge(25);
        employee.setMonthlySalary(8000);

        double salary = empBusinessLogic.calculateYearlySalary(employee);
        assertEquals(96000, salary, 0.0);
    }
}
