/**
 * Public class for employees with getters and setters. Created by Jesse Valley on 4/11/2017.
 * @author Jesse Valley valjesc@dunwoody.edu
 * @version 1.0
 */
public class EmployeeDetails {

    /**
     * The name of the employee
     */
    private String name;
    /**
     * The amount per month that the employee is paid in dollars
     */
    private double monthlySalary;
    /**
     * The age of the employee in years
     */
    private int age;

    /**
     * Public getter to access the employee's name, which is a private variable.
     * @return the employee's name.
     */
    public String getName(){
        return name;
    }

    /**
     * Public setter for an employee name.
     * @param name a string object that represents the employee's name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Public getter to access the employee's monthly salary, which is a private variable.
     * @return the employee's monthly salary
     */

    public double getMonthlySalary() {
        return monthlySalary;
    }

    /**
     * Public setter for the employee's monthly salary.
     * @param monthlySalary a double value that represents the employee's monthly salary
     */

    public void setMonthlySalary(double monthlySalary){
        this.monthlySalary = monthlySalary;
    }

    /**
     * Public getter to access the employee's age, which is a private variable.
     * @return the employee's age
     */

    public int getAge() {
        return age;
    }

    /**
     * Public setter for the employee's age.
     * @param age an integer that represents the employee's age
     */

    public void setAge(int age){
        this.age = age;
    }
}
