/**
 * Public class to perform calculations of employees in the EmployeeDetails class.
 * <p>Created by Jesse Valley on 4/11/2017.</p>
 * @author unascribed
 * @version 1.0
 */
public class EmpBusinessLogic {

    /**
     * Method to calculate the yearly salary by using the getter to get the monthly salary and multiplying that number by 12.
     * @param employeeDetails is an employee of the EmployeeDetails class
     * @return the monthly salary multiplied by 12 months
     */
    public double calculateYearlySalary(EmployeeDetails employeeDetails){
        double yearlySalary = 0;
        yearlySalary = employeeDetails.getMonthlySalary() * 12;
        return yearlySalary;
    }

    /**
     * Method to determine and return the value of the appraisal based on an employee's monthly salary.
     * @param employeeDetails is an employee of the EmployeeDetails class
     * @return the appraisal, determined by the employee's monthly salary
     */
    public double calculateAppraisal(EmployeeDetails employeeDetails) {
        double appraisal = 0;

        if(employeeDetails.getMonthlySalary() < 10000){
            appraisal = 500;
        }else {
            appraisal = 1000;
        }

        return appraisal;
    }
}
