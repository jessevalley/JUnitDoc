/**
 * Created by Jesse Valley on 4/11/2017.
 */
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

/**
 * This class is what actually runs the test using JUnit.
 * @author unascribed
 * @version 1.0
 * @see <a href="http://junit.sourceforge.net/javadoc/">JUnit API</a>
 */
public class TestRunner {
    /**
     * This is the main method that is run and actually performs the JUnit test.
     * @param args normal construction of main method
     */
    public static void main(String[] args) {
        Result result = JUnitCore.runClasses(TestEmployeeDetails.class);

        for(Failure failure : result.getFailures()){
            System.out.println(failure.toString());
        }

        System.out.println(result.wasSuccessful());
    }
}
